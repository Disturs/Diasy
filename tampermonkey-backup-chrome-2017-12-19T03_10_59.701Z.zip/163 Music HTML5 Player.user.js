// ==UserScript==
// @name        163 Music HTML5 Player
// @namespace   http://firefoxbar.github.io/#userscripts
// @include     http://music.163.com/*
// @updateURL   https://github.com/FirefoxBar/userscript/raw/master/163_Music_HTML5_Player/163_Music_HTML5_Player.meta.js
// @downloadURL https://github.com/FirefoxBar/userscript/raw/master/163_Music_HTML5_Player/163_Music_HTML5_Player.user.js
// @run-at      document-start
// @author      Palatoo Simple
// @grant       none
// @version     2
// ==/UserScript==

Object.defineProperty(navigator,'plugins',{});