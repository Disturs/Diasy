// ==UserScript==
// @name        去除重定向
// @namespace   none
// @description 去除百度,搜狗,360的重定向
// @version     1.7
// @include     *://www.baidu.com/*
// @include     *://www.sogou.com/*
// @include     *://www.so.com/*
// @run-at      document-end
// @grant		GM_xmlhttpRequest
// ==/UserScript==
(function () {
    'use strict';
    var resetPage = function (selector) {
        var linkObjs = document.querySelectorAll(selector);
        for (var i = 0, j = linkObjs.length; i < j; i++) {
            var linkObj = linkObjs[i];
            if (linkObj.getAttribute('reset_page') !== 'true') {
                var orgHref = linkObj.href;
                if (orgHref.indexOf('/s?') !== - 1) {
                    var orgHrefAry = orgHref.split('&');
                    var newHref = orgHrefAry[0];
                    for (var n = 1; n < 2; n++) {
                        newHref += '&' + orgHrefAry[n];
                    }
                    if (newHref.indexOf('so.com') !== - 1) {
                        newHref = '/s?' + newHref.split('/s?') [1];
                    }
                    linkObj.href = newHref;
                }
                linkObj.setAttribute('reset_page', 'true');
            }
        }
    }
    var resetURL = function (selector) {
        var linkObjs = document.querySelectorAll(selector);
        for (var i = 0, j = linkObjs.length; i < j; i++) {
            var linkObj = linkObjs[i];
            if (linkObj.getAttribute('reset_url') !== 'true') {
                var orgHref = linkObj.href;
                if (orgHref.indexOf('link?url') !== - 1) {
                    GM_xmlhttpRequest({
                        url: orgHref,
                        headers: {
                            'Accept': 'text/html'
                        },
                        context: orgHref,
                        method: 'GET',
                        onreadystatechange: function (response) {
                            if (response.readyState === 4) {
                                var oldHref = response.context
                                var orgLinkObj = document.querySelectorAll(selector + '[href=\'' + oldHref + '\']') [0];
                                if (orgLinkObj !== null) {
                                    if (oldHref.indexOf('sogou.com/link?url') !== - 1 || oldHref.indexOf('so.com/link?url') !== - 1) {
                                        var responseStr = response.response;
                                        var startNum = responseStr.indexOf('(') + 2;
                                        var endNum = responseStr.indexOf(')') - 1;
                                        orgLinkObj.href = responseStr.substring(startNum, endNum);
                                    }
                                    if (oldHref.indexOf('baidu.com/link?url') !== - 1) {
                                        orgLinkObj.href = response.finalUrl;
                                    }
                                }
                            }
                        }
                    });
                }
                linkObj.removeAttribute('data-click');
                linkObj.removeAttribute('data-res');
                linkObj.setAttribute('reset_url', 'true');
            }
        }
    }
    var mo = new MutationObserver(function () {
        resetURL('div a');
        resetPage('#page a');
    });
    mo.observe(document.body, {
        'childList': true,
        'subtree': true
    });
}) ();

