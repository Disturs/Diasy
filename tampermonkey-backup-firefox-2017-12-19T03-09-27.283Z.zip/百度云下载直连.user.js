// ==UserScript==
// @name    百度云下载直连
// @version      1.0.4
// @description     fbd
// @author      omn
// @include     *://pan.baidu.com/disk/home*
// @grant        none
// @namespace https://greasyfork.org/users/95863
// ==/UserScript==
const LINK = "http://pcs.baidu.com/rest/2.0/pcs/file?method=download&app_id=266719&path=/";

function createStyle(){
  let style = document.createElement('style')
  style.tyle = 'text/css'
  style.textContent = `
   #layoutMain a.direct-donwload{
    vertical-align: middle;
    font-size:14px;
    padding: 6px;
    margin-right: 12px;
    border-radius: 3px;
    color: #3b8cff;
    transition: all .24s ease-in 0s;
    position:absolute;
    top: 8px;
    left: 32px;
    z-index: 99;
  }
  #layoutMain a.direct-donwload:hover {
   color: #fff;
   background-color: #3b8cff;
   box-shadow: 0 0 3px 0 #ccc;   
  }
  #layoutMain dd .file-name a{
   text-indent: 10px;
   display: inline-block;
  }
  #layoutMain dd>*:nth-child(2){
   left: 60px;
  }
  `
  document.head.appendChild(style)
}

function getDir() {
  var node = document.querySelector('#layoutMain ul').lastChild.lastChild
   if (node.style.display=='none') {
     return '/'
   }
   return node.title.replace(/[^\/]+\//,'')
}

function fn(listNode) {
  var ls = listNode.querySelectorAll('dd')  
  if(!ls||!ls.length){
    return
  }
  ls.forEach((item, i)=>{    
    let checker = item.children[1]
    if (/dir/.test(checker.className)) {
      return
    }
    let brother = item.children[2] //.querySelector('.file-name')
    let a = document.createElement('a')
        a.className = 'icon icon-download direct-donwload'
        a.title = '直接下载'
        a.target = '_blank'
        a.href = LINK+getDir()+'/'+brother.querySelector('a').title;
    brother.parentNode.insertBefore(a, brother)
  })
}

document.addEventListener('DOMContentLoaded', function(){
    createStyle() //创建样式 
    var list = document.querySelector('#layoutMain ul').parentElement        
    var sorter = list.nextSibling;
        list = sorter.nextSibling
    var historyNum = 0 
    var path = ''
    var change = false
    sorter.addEventListener('DOMSubtreeModified', function () {
       change = true
    })
    list.addEventListener('DOMSubtreeModified', function () {      
      let dir = getDir()
      let n = list.querySelectorAll('dd').length
      if (n&&(n!=historyNum||dir!=path)) {
        historyNum = n
        path = dir    
        fn(list)
        change = false
      }      
    })
}, false)