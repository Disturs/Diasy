// ==UserScript==
// @name 百度盘直接下载
// @namespace    pan.baidu.com
// @description  就他妈不装百度云管家
// @version      0.0.1
// @match        *://pan.baidu.com/*
// @match        *://yun.baidu.com/*
// @grant        none
// ==/UserScript==

navigator.__defineGetter__("platform", function(){return "Linux";});