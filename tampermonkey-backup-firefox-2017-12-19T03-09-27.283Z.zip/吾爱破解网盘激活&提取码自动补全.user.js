// ==UserScript==
// @icon         http://pan.baidu.com/box-static/disk-system/images/favicon.ico
// @name         吾爱破解网盘激活&提取码自动补全
// @namespace    1649991905@qq.com
// @author       猎隼丶止戈
// @description	 激活吾爱破解论坛中的百度网盘链接，并自动补全提取码然后跳转到分享地址
// @match        *://www.52pojie.cn/thread*
// @match        *://pan.baidu.com/share/*
// @require      http://cdn.bootcss.com/jquery/1.8.3/jquery.min.js
// @version      0.0.1
// @grant        GM_addStyle
// ==/UserScript==
(function () {
    'use strict';
    /***********************************************自定义CSS样式-开始**********************************************/
    GM_addStyle('.my_baidu_link{color:green!important;text-decoration:none!important;border: 1px dotted green;padding: 2px;}');
    /***********************************************自定义CSS样式-结束**********************************************/

    var location = self.location;
    var location_pathname = location.pathname;

    /************************************************自定义函数-开始***********************************************/

    /**
     *
     * 提取网盘链接中的密码
     * str  要匹配的字符串
     * rule 分割符
     */
    var arrayTool = {
        getSplit: function (str, rule) {
			return str.split(rule);
		},
		getUbound: function (array) {
			return (array[array.length - 1]).replace(/(^\s*)|(\s*$)/g, "");
		},
		length: function (array) {
			return array.length;
		}
    };

    /**
     *
     *渲染网盘链接为蓝链
     *
     */
    function activelink(re, nre) {
        $('.plc').each(function (index, value) {
            //已是蓝链
            var link = ($(this).html()).match(nre);
            if (link) {
                var ss = $(this).html();
                ss = ss.replace(nre, '$1" class="my_baidu_link"');
                $(this).html(ss);

                //提取码与网盘链接拼接
                var pattern = /密码[：:]?[ A-Za-z0-9]*/g;
                var pass = ($(value).html()).match(pattern);
                if (pass) {
                    $(value).find(".my_baidu_link").each(function (i, v) {
                        var passArray = arrayTool.getSplit(pass[i], ":");
                        if (passArray.length < 2) {
                            passArray = arrayTool.getSplit(pass[i], "：")
                        }

                        var o_href = $(v).attr("href");
                        var n_href = o_href + "#" + arrayTool.getUbound(passArray);
                        $(v).attr("href", n_href)

                        //Debug
                        console.log("URL = " + o_href + " ---- " + "提取码 = " + arrayTool.getUbound(passArray));
                    });
                }
            } else {
                //非蓝链
                link = ($(this).html()).match(re);
                if (link) {
                    var ss = $(this).html();
                    ss = ss.replace(re, '<a target="_blank" href="$1" class="my_baidu_link">$1</a>');
                    $(this).html(ss);

                    //提取码与网盘链接拼接
                    var pattern = /密码[：:]?[ A-Za-z0-9]*/g;
                    var pass = ($(value).html()).match(pattern);
                    if (pass) {
                        $(value).find(".my_baidu_link").each(function (i, v) {
                            var passArray = arrayTool.getSplit(pass[i], ":");
                            if (passArray.length < 2) {
                                passArray = arrayTool.getSplit(pass[i], "：")
                            }

                            var o_href = $(v).attr("href");
                            var n_href = o_href + "#" + arrayTool.getUbound(passArray);
                            $(v).attr("href", n_href)

                            //Debug
                            console.log("URL = " + o_href + " ---- " + "提取码 = " + arrayTool.getUbound(passArray));
                        });
                    }
                }
            }
        });
    }

    /**
     *
     *提取网盘链接中的密码
     *
     */
    var getCode = function (rule) {
        var code = location.hash.slice(1, 5);
        if ((rule || /([a-z\d]{4})/i.exec(code))) {
            code = RegExp.$1;
        } else code = null;
        return code;
    };
    /************************************************自定义函数-结束***********************************************/

    $(function () {
        //渲染网盘链接为蓝链
        var re_baidu = /((?:https?:\/\/)?(?:yun|pan|eyun).baidu.com\/(?:s\/\w*|share\/\S*\d))/g;
        var re_ex_baidu = /(href="https?:\/\/(yun|pan|eyun).baidu.com\/(?:s\/\w*|share\/\S*\d))/g;
        activelink(re_baidu, re_ex_baidu);

        //百度网盘提取码自动补全
        if (location_pathname.indexOf("/share/") != -1 && $("#accessCode") != null) {
            var code = getCode();
            $("#accessCode").val(code);
            $("#submitBtn").click();
        }
    });
})();