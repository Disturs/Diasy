// ==UserScript==
// @id           ctfile@405647825@qq.com
// @name         城通网盘、皮皮盘、牛盘显示正确下载地址
// @namespace    http://weibo.com/pendave
// @version      0.6
// @description  城通网盘、皮皮盘、牛盘显示正确下载地址!去掉遮挡的popjump透明层！自动跳到第二页！
// @author       405647825@qq.com
// @include      *ctfile.com*
// @include      *pipipan.com*
// @include      *6pan.cc/file-*html
// @include      *666pan.cc/file-*html
// @include      *777pan.cc/file-*html
// @include      *888pan.cc/file-*html
// @require  https://cdn.jsdelivr.net/clipboard.js/1.5.13/clipboard.min.js
// @grant        none
// ==/UserScript==
//牛盘
if(location.href.match(/666pan\.cc|6pan\.cc|777pan\.cc|888pan\.cc/g) ){
	var fileCode = location.href.match(/(\d+)\./g)[0].replace('.','');
	//document.querySelector('div.file_item').childNodes[1].innerHTML += '&nbsp;<a id="free_down_link" class="color_btn btn_deep_blue txtwhite" href="http://www.777pan.cc/cd.php?file_id=' + fileCode + '" target="_blank">⇩ 直接下载</a><span>8分钟一次</span>';
	//document.querySelector('#free_down_link').click();
	location.href = 'http://www.777pan.cc/down-' + fileCode + '.html';
}
//城通网盘、皮皮盘
//第一页自动点击按钮
if(location.href.match(/ctfile\.com|pipipan\.com/g) && document.querySelector('#free_down_link')){
	document.querySelector('#free_down_link').click();
}
//有pop广告的移除
var popNode = document.querySelector('a[href*="popjump.php"]');
if(popNode !== null){
	popNode.remove();
}
//获取第二页里的真实下载地址 建立copy按钮
var down = document.querySelector('#free_down_link').onclick.toString().match(/((http|ftp|https):\/\/)(([a-zA-Z0-9\._-]+\.[a-zA-Z]{2,6})|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,4})*(\/[a-zA-Z0-9\&%_\.\/-~-]*)?/gi)[0];
setTimeout(document.querySelector('#free_down_link[onclick^="free_down_action"]').nextSibling.innerHTML = '<button class="mybtn" data-clipboard-text="'+ down +'">Copy真实下载地址</button>',200);
var clipboard = new Clipboard('.mybtn');

clipboard.on('success', function(e) {
	console.log(e);
});

clipboard.on('error', function(e) {
	console.log(e);
});
